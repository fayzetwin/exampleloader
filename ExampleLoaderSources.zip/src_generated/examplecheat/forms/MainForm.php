<?php
namespace examplecheat\forms;

use std, gui, framework, examplecheat;


class MainForm extends AbstractForm
{

    /**
     * @event continueButton.action 
     */
    function doContinueButtonAction(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->loadForm('installForm');

        
    }

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		app()->shutdown();

        
    }


}
