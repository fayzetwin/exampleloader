<?php
namespace examplecheat\forms;

use std, gui, framework, examplecheat;
use php\gui\UXDialog; 


class installIdleForm extends AbstractForm
{

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2


		if (uiConfirm('А вы уверены? Процесс установки чита будет остановлен, в случае отмены.'))
			$this->loadForm('installForm');

		else
			UXDialog::show('Ну, ладно.');

        
    }



    /**
     * @event construct 
     */
    function doConstruct(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->form('installForm')->label->hide();

        
    }



}
