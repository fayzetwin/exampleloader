<?php
namespace examplecheat\modules;

use std, gui, framework, examplecheat;


class installIdleModule extends AbstractModule
{

    /**
     * @event timerInstall.action 
     */
    function doTimerInstallAction($script)
    {    
        $this->progressBar->progress += 1;
        
        if($this->progressBar->progress >= 100) {
            $script->stop();
        }
    }


}
