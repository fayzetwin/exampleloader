<?php
namespace examplecheat\modules;

use std, gui, framework, examplecheat;


class AppModule extends AbstractModule
{

}