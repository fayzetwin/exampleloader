<?php
namespace examplecheat\modules;

use std, gui, framework, examplecheat;


class MainModule extends AbstractModule
{

    /**
     * @event timer.action 
     */
    function doTimerAction($script)
    {
        $this->hide();
        $this->form('MainForm')->show();
    }

}
