<?php
namespace examplecheat\forms;

use std, gui, framework, examplecheat;


class MainForm extends AbstractForm
{

    /**
     * @event continueButton.action 
     */
    function doContinueButtonAction(UXEvent $e = null)
    {    
        
    }

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        
    }


}
