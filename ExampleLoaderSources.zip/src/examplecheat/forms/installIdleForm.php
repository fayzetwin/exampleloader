<?php
namespace examplecheat\forms;

use std, gui, framework, examplecheat;


class installIdleForm extends AbstractForm
{

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        
    }



    /**
     * @event construct 
     */
    function doConstruct(UXEvent $e = null)
    {    
        
    }



}
